To create the empty codec binary sections required as part of the linker process use the codec_cleaner utility in the tools folder

codec_cleaner -C and move the resultant file codec_bin_section_1.bin to this folder
